var max = 10;

for(var i = 0; max > i; i++) {
    console.log(i);
}